function validate(form) {var e = form.elements, m = '';

var alphaExp = /^[0-9a-zA-Z\s]+$/;
var sps = /^[\s]+$/;
  if(!e['proj_nme'].value) {m += '- Name of Project is required.\n';}
  else if(e['proj_nme'].value.match(sps)) {m += '- Name of Project is required.\n';}
  if(!e['proj_nme'].value.match(alphaExp)){ m += '- Name of Project only alphabets and numeric allowed.\n';}
  if(!e['user'].value) {m += '- Username is required.\n';}
  if(!e['pwd'].value) {m += '- Password is required.\n';}
  if(e['pwd'].value != e['pwd1'].value) {
    m += '- Your password and verify password do not match.\n';
  }
  
  if(m) {
    alert('The following error(s) occurred:\n\n' + m);
    return false;
  }
  return true;
}
