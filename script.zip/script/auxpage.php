var hide_empty_list=true;

addListGroup("vehicles", "car-makers");

//addList("car-makers", "All", "All", "dummy-maker");
addList("car-makers", "Nucleotide", "Nucleotide", "Nucleotide", 1);
addList("car-makers", "EST", "Nucest", "Nucest" );
addList("car-makers", "GSS", "Nucgss", "Nucgss" );
addList("car-makers", "Protein", "Protein", "Protein");
addList("car-makers", "SNP", "SNP", "SNP");




//addList("dummy-maker", "", "", "dummy-car");

//addOption("dummy-car", "Not available", "");

addList("Nucleotide", "All Fields", "All Fields", 1);
addList("Nucleotide", "UID", "UID");
addList("Nucleotide", "filter", "filter");
addList("Nucleotide", "Text Word", "Text Word");
addList("Nucleotide", "Title", "Title");
addList("Nucleotide", "Keyword", "Keyword");
addList("Nucleotide", "Author", "Author");
addList("Nucleotide", "Journal", "Journal");
addList("Nucleotide", "Volume", "Volume");
addList("Nucleotide", "Issue", "Issue");
addList("Nucleotide", "Page Number", "Page Number");
addList("Nucleotide", "Organism", "Organism");
addList("Nucleotide", "Accession", "Accession");
addList("Nucleotide", "Primary Accession", "Primary Accession");
addList("Nucleotide", "Gene Name", "Gene Name");
addList("Nucleotide", "Protein Name", "Protein Name");
addList("Nucleotide", "RN Number", "RN Number");
addList("Nucleotide", "EC Number", "EC Number");
addList("Nucleotide", "Publication Date", "Publication Date");
addList("Nucleotide", "Modification Date", "Modification Date");



//addOption("dummy-NCBI_Nucleotide", "Not available", "");


addList("Nucest", "All Fields", "All Fields");
addList("Nucest", "UID", "UID");
addList("Nucest", "filter", "filter");
addList("Nucest", "Text Word", "Text Word");
addList("Nucest", "Title", "Title");
addList("Nucest", "Keyword", "Keyword");
addList("Nucest", "Author", "Author");
addList("Nucest", "Journal", "Journal");
addList("Nucest", "Volume", "Volume");
addList("Nucest", "Issue", "Issue");
addList("Nucest", "Organism", "Organism");
addList("Nucest", "Accession", "Accession");
addList("Nucest", "Primary Accession", "Primary Accession");
addList("Nucest", "Gene Name", "Gene Name");
addList("Nucest", "Protein Name", "Protein Name");
addList("Nucest", "EC Number", "EC Number");
addList("Nucest", "RN Number", "RN Number");
addList("Nucest", "Publication Date", "Publication Date");
addList("Nucest", "Modification Date", "Modification Date");
addList("Nucest", "Primary Organism", "Primary Organism");
addList("Nucest", "EST Name", "EST Name");
addList("Nucest", "Clone ID", "Clone ID");
addList("Nucest", "Library Name", "Library Name");
addList("Nucest", "Submitter Name", "Submitter Name");
addList("Nucest", "Citation Title", "Citation Title");


addList("Nucgss", "All Fields", "All Fields");
addList("Nucgss", "UID", "UID");
addList("Nucgss", "filter", "filter");
addList("Nucgss", "Text Word", "Text Word");
addList("Nucgss", "Title", "Title");
addList("Nucgss", "Keyword", "Keyword");
addList("Nucgss", "Author", "Author");
addList("Nucgss", "Journal", "Journal");
addList("Nucgss", "Volume", "Volume");
addList("Nucgss", "Issue", "Issue");
addList("Nucgss", "Organism", "Organism");
addList("Nucgss", "Accession", "Accession");
addList("Nucgss", "Primary Accession", "Primary Accession");
addList("Nucgss", "Gene Name", "Gene Name");
addList("Nucgss", "Protein Name", "Protein Name");
addList("Nucgss", "EC Number", "EC Number");
addList("Nucgss", "RN Number", "RN Number");
addList("Nucgss", "Publication Date", "Publication Date");
addList("Nucgss", "Modification Date", "Modification Date");
addList("Nucgss", "Genome Project", "Genome Project");
addList("Nucgss", "Primary Organism", "Primary Organism");
addList("Nucgss", "EST Name", "EST Name");
addList("Nucgss", "Clone ID", "Clone ID");
addList("Nucgss", "Library Name", "Library Name");
addList("Nucgss", "Submitter Name", "Submitter Name");
addList("Nucgss", "Library Class", "Library Class");


addList("Protein", "All Fields", "All Fields");
addList("Protein", "UID", "UID");
addList("Protein", "filter", "filter");
addList("Protein", "Text Word", "Text Word");
addList("Protein", "Title", "Title");
addList("Protein", "Keyword", "Keyword");
addList("Protein", "Author", "Author");
addList("Protein", "Journal", "Journal");
addList("Protein", "Volume", "Volume");
addList("Protein", "Issue", "Issue");
addList("Protein", "Organism", "Organism");
addList("Protein", "Accession", "Accession");
addList("Protein", "Primary Accession", "Primary Accession");
addList("Protein", "Gene Name", "Gene Name");
addList("Protein", "Protein Name", "Protein Name");
addList("Protein", "EC Number", "EC Number");
addList("Protein", "RN Number", "RN Number");
addList("Protein", "Publication Date", "Publication Date");
addList("Protein", "Modification Date", "Modification Date");
addList("Protein", "Substance Name", "Substance Name");
addList("Protein", "Properties", "Properties");
addList("Protein", "SeqID String", "SeqID String");
addList("Protein", "Sequence Length", "Sequence Length");
addList("Protein", "Feature key", "Feature key");
addList("Protein", "Genome Project", "Genome Project");
addList("Protein", "Primary Organism", "Primary Organism");

//addOption("dummy-NCBI_Protein", "Not available", "");

addList("SNP", "All Fields", "All Fields");
addList("SNP", "UID", "UID");
addList("SNP", "Reference SNP ID", "Reference SNP ID");
addList("SNP", "Chromosome", "Chromosome");
addList("SNP", "Gene Name", "Gene Name");
addList("SNP", "Accession", "Accession");
addList("SNP", "LocusLink ID", "LocusLink ID");
addList("SNP", "Text Word", "Text Word");
addList("SNP", "Title", "Title");
addList("SNP", "Organism", "Organism");
addList("SNP", "Function Class", "Function Class");
addList("SNP", "Primary Accession", "Primary Accession");
addList("SNP", "Genotype", "Genotype");
addList("SNP", "Protein Name", "Protein Name");
addList("SNP", "EC Number", "EC Number");
addList("SNP", "RN Number", "RN Number");
addList("SNP", "Publication Date", "Publication Date");
addList("SNP", "Modification Date", "Modification Date");
addList("SNP", "Genome Project", "Genome Project");
addList("SNP", "Primary Organism", "Primary Organism");
addList("SNP", "NREF", "NREF");
addList("SNP", "Map Weight", "Map Weight");
addList("SNP", "Method Class", "Method Class");
addList("SNP", "Submitter SNP ID", "Submitter SNP ID");
addList("SNP", "Local SNP ID", "Local SNP ID");
addList("SNP", "Allele", "Allele");
addList("SNP", "SNP Class", "SNP Class");
addList("SNP", "Gene Description", "Gene Description");
addList("SNP", "Base Position", "Base Position");
addList("SNP", "Contig Position", "Contig Position");
addList("SNP", "Reference Amino Acid", "Reference Amino Acid");
addList("SNP", "Variant Amino Acid", "Variant Amino Acid");
addList("SNP", "Reference SNP", "Reference SNP");
addList("SNP", "SNP Index", "SNP Index");

addOption("dummy-NCBI_SNP", "Not available", "");


addOption("NCBI_PubMed-Cars", "Select a model", "");
addOption("NCBI_PubMed-Cars", "300M", "300M");
addOption("NCBI_PubMed-Cars", "PT Cruiser", "PT Cruiser", 1);
addOption("NCBI_PubMed-Cars", "Concorde", "Concorde");
addOption("NCBI_PubMed-Cars", "Sebring Coupe", "Sebring Coupe");
addOption("NCBI_PubMed-Cars", "Sebring Sedan", "Sebring Sedan");
addOption("NCBI_PubMed-Cars", "Sebring Convertible", "Sebring Convertible");

addOption("NCBI_PubMed-SUVs/Van", "Select a model", "");
addOption("NCBI_PubMed-SUVs/Van", "Town & Country", "Town & Country");
addOption("NCBI_PubMed-SUVs/Van", "Voyager", "Voyager");



addOption("NCBI_SNP-Cars", "Select a model", "");
addOption("NCBI_SNP-Cars", "Intrepid", "Intrepid");
addOption("NCBI_SNP-Cars", "Neon", "Neon");
addOption("NCBI_SNP-Cars", "SRT-4", "SRT-4");
addOption("NCBI_SNP-Cars", "Stratus Coupe", "Stratus Coupe");
addOption("NCBI_SNP-Cars", "Stratus Sedan", "Stratus Sedan");
addOption("NCBI_SNP-Cars", "Viper", "Viper");

addOption("NCBI_SNP-SUVs/Van", "Select a model", "");
addOption("NCBI_SNP-SUVs/Van", "Caravan", "Caravan");
addOption("NCBI_SNP-SUVs/Van", "Durango", "Durango");
addOption("NCBI_SNP-SUVs/Van", "Ram Van", "Ram Van");

addOption("NCBI_SNP-Trucks", "Select a model", "");
addOption("NCBI_SNP-Trucks", "Dakota", "Dakota");
addOption("NCBI_SNP-Trucks", "Ram Pickup", "Ram Pickup");

addList("Uniprot", "Select vehicle type", "", "dummy-Uniprot");
addList("Uniprot", "Cars", "car", "Uniprot-Cars");
addList("Uniprot", "SUVs/Van", "suv", "Uniprot-SUVs/Van");
addList("Uniprot", "Trucks", "truck", "Uniprot-Trucks");

addOption("dummy-Uniprot", "Not available", "");

addOption("Uniprot-Cars", "Select a model", "");
addOption("Uniprot-Cars", "ZX2", "ZX2");
addOption("Uniprot-Cars", "Focus", "Focus");
addOption("Uniprot-Cars", "Taurus", "Taurus");
addOption("Uniprot-Cars", "Crown Victoria", "Crown Victoria");
addOption("Uniprot-Cars", "Mustang", "Mustang");
addOption("Uniprot-Cars", "Thunderbird", "Thunderbird");

addOption("Uniprot-SUVs/Van", "Select a model", "");
addOption("Uniprot-SUVs/Van", "Escape", "Escape");
addOption("Uniprot-SUVs/Van", "Explorer", "Explorer");
addOption("Uniprot-SUVs/Van", "Expedition", "Expedition");
addOption("Uniprot-SUVs/Van", "Excursion", "Excursion");
addOption("Uniprot-SUVs/Van", "Windstar", "Windstar");
addOption("Uniprot-SUVs/Van", "Econoline", "Econoline");

addOption("Uniprot-Trucks", "Select a model", "");
addOption("Uniprot-Trucks", "Ranger", "Ranger");
addOption("Uniprot-Trucks", "F-150", "F-150");
addOption("Uniprot-Trucks", "F-250", "F-250");
addOption("Uniprot-Trucks", "F-350", "F-350");