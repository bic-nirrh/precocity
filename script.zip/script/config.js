var hide_empty_list=true;

addListGroup("vehicles", "car-makers");

//addList("car-makers", "All", "All", "dummy-maker");
addList("car-makers", "Gene Information", "Gene Information", "Gene Information", 1);
addList("car-makers", "Protein Information", "Protein Information", "Protein Information" );
addList("car-makers", "Gene Ontology (GO)", "GO", "GO" );
addList("car-makers", "SNPs", "SNP", "SNP");
addList("car-makers", "Associated Diseases", "Associated Diseases", "Associated Diseases");
addList("car-makers", "References", "References", "References");


//Gene Information

addList("Gene Information", "Gene Symbol", "Gene Symbol", 1);
addList("Gene Information", "Gene Name", "Gene Name");
addList("Gene Information", "Aliases", "Aliases");
addList("Gene Information", "Entrez Gene ID", "Entrez Gene ID");
addList("Gene Information", "Chromosomal Location", "Chromosomal Location");
addList("Gene Information", "Gene Summary", "Gene Summary");
addList("Gene Information", "GeneCards ID", "GeneCards ID");
addList("Gene Information", "UniGene", "UniGene");
addList("Gene Information", "RefSeq DNA", "RefSeq DNA");
addList("Gene Information", "RefSeq mRNA", "RefSeq mRNA");



//Protein Information



addList("Protein Information", "Protein Name", "Protein Name",1);
addList("Protein Information", "Function", "Function");
addList("Protein Information", "Refseq Proteins", "Refseq Proteins");
addList("Protein Information", "UniProt", "UniProt");
addList("Protein Information", "RCSB PDB", "RCSB PDB");
addList("Protein Information", "Interpro ID", "Interpro ID");

//GO
addList("GO", "Gene Symbol", "Gene", 1);
addList("GO", "GO ID", "GO ID");
addList("GO", "Ontology", "Ontology");
addList("GO", "Definition", "Definition");

//Associated Disease

addList("Associated Diseases", "Gene Symbol", "Gene", 1);
addList("Associated Diseases", "Disease", "Disease");

//Associated Disease
addList("SNP", "Gene Symbol", "Gene", 1);
addList("SNP", "SNP ID", "SNP ID");
addList("SNP", "Upstream Sequence", "Upstream Sequence");
addList("SNP", "SNP", "SNP");
addList("SNP", "Downstream Sequence", "Downstream Sequence");

//Associated Disease

addList("References", "Pubmed ID", "Pubmed ID", 1);
addList("References", "Title", "Title");
addList("References", "Author", "Author");
addList("References", "Abstract", "Abstract");
addList("References", "Source", "Source");


