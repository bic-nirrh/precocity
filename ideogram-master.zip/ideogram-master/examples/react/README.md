# Ideogram in React
This is a very basic example of integrating Ideogram with [React](https://reactjs.org/).

For more examples, check out [React Ideogram](https://github.com/eweitz/react-ideogram)!

# Install
```
git clone https://github.com/eweitz/ideogram
cd ideogram/examples/react
npm install
npm start
```

# Output
After executing the steps above, you should see the following:
![Ideogram in React screenshot](https://raw.githubusercontent.com/eweitz/ideogram/master/examples/react/ideogram_react_example.png)
