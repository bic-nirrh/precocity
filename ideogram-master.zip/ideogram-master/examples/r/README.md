# Ideogram in R

You can find an example of integrating Ideogram with R in [wangtulao/ideogRam](https://github.com/wangtulao/ideogRam), by Freeman S. Wang.

More examples showing the breadth of Ideogram's functionality are at https://eweitz.github.io/ideogram/.