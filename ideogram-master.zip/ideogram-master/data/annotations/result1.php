<?php
session_start();
error_reporting(0);
include("head.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel ="icon" type="image/ico" href="favicon.ico"></link>
<link rel ="shortcut icon" href="favicon.ico"></link>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script>

function toggle(thisname) {
tr=document.getElementsByTagName('tr')
for (i=0;i<tr.length;i++){
if (tr[i].getAttribute(thisname)){
if ( tr[i].style.display=='none' ){
tr[i].style.display = '';
}
else {
tr[i].style.display = 'none';
}
}
}
}

</script>
<script type="text/javascript" src="http://code.jquery.com/jquery-1.6.2.js"></script>
<script>
jQuery(function($){
$(".expander").click(function() {
    if ($(this).hasClass("expander")) {
        $(this).removeClass("expander");
    }
    else {
         $(this).addClass("expander");
    } 
	})
});
</script>
<script language="javascript" src="css/jsval.js">
    </script>
<script type="text/javascript" src="css/dropdown.js"></script>
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
a:link {
	text-decoration: none;
	color: #900;
}
a:visited {
	text-decoration: none;
	color: #930;
}
a:hover {
	text-decoration: none;
	color: #930;
}
a:active {
	text-decoration: none;
	color: #662100;
}
p {
    width:800px;
    height:60px;
    line-height:20px; /* Height / no. of lines to display */
    overflow:hidden;
}
body,td,th {
	font-size: 10pt;
	color: #000;
	font-family: Verdana, Geneva, sans-serif;
}
body {
	background-color: #E0E0E0;
}
.expander {
    height: 4.3em;
    overflow: hidden;
    cursor: pointer;
}
-->
</style></head>

<body topmargin="0" leftmargin="0" >
<table width="90%" border="0" cellspacing="0" cellpadding="0" align="center" >
 
  <tr>
    <td valign="top" bgcolor="#FFFFFF">
    <?php 
	
	
	$qury =$_REQUEST["qury"];
//	echo $qury;
	$opt=$_REQUEST["opt"];
	$lookFor=$qury;
	$replacement="<strong>$qury</strong>";
	if($qury=="")
	{echo "<p align='center'>There is no supplied query</p>";}
	else
	{
	if($opt==1)
	{
	$res = mysql_query("select gene_name, entrez_gene, aliases, approved_name, genomic_loc from gene where gene_name LIKE '%$qury%' or approved_name LIKE '%$qury%' OR aliases LIKE '%$qury%' or entrez_gene LIKE '%$qury%' order by gene_name"); 
	$cnt1=mysql_num_rows($res);
//	echo $cnt1;
	}
	elseif($opt==2)
	{
	$res = mysql_query("select * from gene where entrez_summary LIKE '%$qury%' or `function` LIKE '%$qury%' or ref_seq_proteins LIKE '%$qury%' or uniprot_id LIKE '%$qury%' or gene_name LIKE '%$qury%'"); 
	$cnt1=mysql_num_rows($res);
	}
	elseif($opt==3)
	{
		
		//$rrs=mysql_query("select count(DISTINCT go_id) as numm from go_new where (go_function LIKE '%$qry%'or  go_id like '%$qry%') and (type = '$type') ");
			$ress=mysql_query("select go_function, go_id, type from gene2go where go_function LIKE '%$qry%' or go_id like '%$qry%' or type like '%$qry%' order by type");
		
	//$res = mysql_query("select * from go_new where geneSymbol LIKE '%$qury%' or go_id LIKE '%$qury%' or type LIKE '%$qury%' or go_function LIKE '%$qury%' or evidence LIKE '%$qury%' or pmid = '$qury' order by type"); 
	//echo "select * from go_new where geneSymbol LIKE '%$qury%' or go_id LIKE '%$qury%' or type LIKE '%$qury%' or go_function LIKE '%$qury%' or evidence LIKE '%$qury%' order by type"."<br>";
	$num=mysql_num_rows($ress);
	}
	elseif($opt==4)
	{
	$res = mysql_query("select * from snp where gene_symbol LIKE '%$qury%' or snpid LIKE '%$qury%' or pmid LIKE '%$qury%'");
	$cnt1=mysql_num_rows($res);
	}
	elseif($opt==5)
	{
	$res=mysql_query("select distinct disease_merge from disease_tertiary where geneSymbol LIKE '%$qury%' or disease_merge LIKE '%$qury%' or pmid LIKE '%$qury%'");
	
	//echo "select distinct disease_merge from disease_tertiary where geneSymbol LIKE '%$qury%' or disease_merge LIKE '%$qury%' or pmid LIKE '%$qury%'"."<br>";
	$cnt1=mysql_num_rows($res);
	}
	elseif($opt==8)
	{
	$res=mysql_query("select * from pubmed where PubMed_Unique_Identifier LIKE '%$qury%' or Title LIKE '%$qury%' or Source LIKE '%$qury%' or Abstract LIKE '%$qury%' or Full_Author LIKE '%$qury%' ORDER BY Date_Created DESC");
	$cnt1=mysql_num_rows($res);
	}
	elseif($opt==6)
	{
	$res=mysql_query("select distinct pathwayid, pathwayname from kegg_path, gene where (pathwayname like '%$qury%' or geneSymbol like '%$qury%' or pathwayid like '%$qury%' or entrezid like '%$qury%') and (kegg_path.entrezid = gene.entrez_gene) UNION select distinct pathwayid, pathwayname from reactome, gene where (pathwayname like '%$qury%' or geneSymbol like '%$qury%' or pathwayid like '%$qury%' or entrezid like '%$qury%') and (reactome.entrezid = gene.entrez_gene)");
	
	//echo "select distinct pathwayid, pathwayname from kegg_path, gene where (pathwayname like '%$qury%' or geneSymbol like '%$qury%' or pathwayid like '%$qury%' or entrezid like '%$qury%') and (kegg_path.entrezid = gene.entrez_gene) UNION select distinct pathwayid, pathwayname from reactome, gene where (pathwayname like '%$qury%' or geneSymbol like '%$qury%' or pathwayid like '%$qury%' or entrezid like '%$qury%') and (reactome.entrezid = gene.entrez_gene);"."<br>";
	$cnt1=mysql_num_rows($res);
	}
	
?>
	
  <table width="98%" border="0" align="center" cellpadding="5" cellspacing="0">
      <tr>
        <td><table width="100%" border="0" align="center" cellpadding="5" cellspacing="0">
      <tr>
        <td><?php if($opt==1)
		{ ?>
       
        <h3 align="center"><strong>Gene Information</strong></h3>
         <p align="center"><?php echo "Search term: $qury"; ?></p>
          <table width="100%" border="0" cellspacing="0" cellpadding="4">
  <tr>
    <td><table width="99%" border="0" cellspacing="0" cellpadding="4" bordercolor="#000000">
      <tr bgcolor="#DEEDEF">
        <td width="15%"><div align="left"><strong>Gene Symbol</strong></div></td>
        <td width="15%"><div align="left"><strong>Entrez ID</strong></div></td>
        <td width="27%"><div align="left"><strong>Aliases</strong></div></td>
        <td width="15%"><div align="left"><strong>Gene Name</strong></div></td>
        <td width="13%"><div align="left"><strong>Chromosomal Location</strong></div></td>
        
        </tr>
        <?php 
		$ii=1;
		while($row = mysql_fetch_array($res))
		{ 
	?>
      <tr <?php if($ii%2 == 0){ ?>bgcolor="#DEEDEF" <?php }?>>
        <td valign="top"><a href= "gene_det.php?gene=<?php echo $row["gene_name"]; ?>" target="_blank"><?php  echo $row["gene_name"]; ?></a></td>
        <td valign="top"><div align="left">
          <?php $gene_id=$row["entrez_gene"];
		
			  $gene_id=str_replace($lookFor, $replacement, $gene_id);
		?><a href= "https://www.ncbi.nlm.nih.gov/gene/<?php echo $row["entrez_gene"]; ?>" target="_blank"><?php echo $gene_id; ?></a>
        </div></td>
        <td valign="top"><div align="left">
        
          <?php
		  $aliases=$row["aliases"];
		 
			  $aliases=str_replace($lookFor, $replacement, $aliases);
			   
		
		echo $aliases; ?>
        </div></td>
        <td valign="top"><div align="left">
          <?php $official_name = $row["approved_name"]; 
					$official_name =trim($official_name);
					$official_name=ucfirst($official_name);	
		$rep = array(" | ", "  | ", "|", " |");
		$official_name=str_replace($rep, ", ", $official_name);
		$official_name=str_replace($lookFor, $replacement, $official_name);
		echo $official_name;
		?>
        </div></td>
        <td><div align="left"><?php echo $row["genomic_loc"]; ?></div></td>
        
        </tr> <?php  $ii++;} ?>
    </table>
    <?php } 
	elseif($opt==2)
	{ 
	?>
	
   
    <h3 align="center"><strong>Protein Information</strong></h3>
     <p align="center"><?php echo "Search term: $qury"; ?></p>
     
     <table width="98%" border="0" cellspacing="5" cellpadding="6">
  <tr bgcolor="#DEEDEF">
        <td width="10%"><strong>Gene symbol</strong></td>
        <td width="20%"><div align="center"><strong>Protein Name</strong></div></td>
        <td width="35%"><div align="center"><strong>Summary(NCBI)</strong></div></td>
        <td width="35%"><div align="center"><strong>Function(Uniprot)</strong></div></td>
        </tr></table>
        <?php $ii=1;
		while($row = mysql_fetch_array($res))
		{ ?>
        <div class="expander">
        <table width="98%" border="0" cellspacing="5" cellpadding="6">
        <tr <?php if($ii%2 == 0){ ?>bgcolor="#DEEDEF" <?php }?>>
 
   <td width="10%" valign="top" ><div align="justify"><a href="gene_pcos.php?gene=<?php echo $row["gene_name"]; ?>#protein" target="_blank" ><?php echo $row["gene_name"]; ?></a></div></td>
   <td width="20%" valign="top"><div align="justify">
     <?php $definition = $row["description"]; $definition =trim($definition);
		$definition=ucfirst($definition);	
		$rep = array(" | ", "  | ", "|", " |");
		$definition=str_replace($rep, ", ", $definition);
		echo $definition; ?>
   </div></td>
    <td width="35%" valign="top"><div align="justify">
      <?php 
		$definition = $row["entrez_summary"]; 
		$definition =trim($definition);
		$definition=ucfirst($definition);	
		$rep = array(" |", "  |", "|");
		$definition=str_replace($rep, ",", $definition);
		echo $definition; ?>
    </div></td>
   <td width="35%" valign="top">
          <div align="justify">
            <?php $function = $row["function"];
		$function=str_replace("Function: ", " ", $function);
		$function=str_replace("FUNCTION: ", " ", $function);
		$function =preg_replace('/{(.*?)}/', ' ', $function);
		$function = preg_replace("/\.+$/", " ", $function);
		$function = preg_replace("/~\s+/", " ", $function);
		$function = preg_replace("/\.+$/", " ", $function);
		echo $function;?>
          </div></td>
  </tr>
     </table></div>
  <?php 
  $ii++;
   } ?>
  


     <?php } 
		elseif($opt==3)
	{
		?>
     <h3 align="center"><?php echo "Search term: $qury"; ?></h3>
        <p align="left"><strong>Ontology Terms</strong></p>
       <?php
	   
	    if($num>0)
		{
		?>
          <table width="100%" border="0" cellspacing="1" cellpadding="6">
            <tr align="center" valign="top" bgcolor="#DEEDEF">
              <td width="25%" align="left"><strong>Ontology term</strong></td>
              <td width="8%" align="left"><strong>Accession</strong></td>
              <td width="15%" align="left"><strong>Ontology type</strong></td>
              <td width="52%" align="left"><strong>Gene symbol</strong></td>
            </tr>
            <?php $i=1;
  while($row1=mysql_fetch_array($ress))
	{ 
	$function=$row1["go_function"];
	$go_id=$row1["go_id"];
	$type=$row1["type"];
	$res=mysql_query("select distinct group_concat(DISTINCT geneSymbol separator ', ') as geneSymbol from go_new where go_id='$go_id' order by geneSymbol");
	$num1=mysql_num_rows($res);
	?>
            <tr <?php if($i%2 == 0){ ?>bgcolor="#DEEDEF" <?php }?>>
              <td rowspan="<?php
			   echo $num1+1; ?>" valign="top"  align = "justify"><a href="http://amigo.geneontology.org/amigo/term/<?php echo $go_id; ?>" target="_blank"><?php echo ucfirst($function); ?></a></td>
              
            </tr>
            <?php 
	
		if($num1>0)
		{
	?>
            <?php while($row2=mysql_fetch_array($res))
	{ $gene=$row2["geneSymbol"];
		$ga= explode(",",$gene);
$gc=0;
	?>
            <tr <?php if($i%2 == 0){ ?>bgcolor="#DEEDEF" <?php }?>>
            <td valign="top" align = "justify"><a href="go_pcos.php?go=<?php echo $go_id; ?>"target="_blank"><?php echo $go_id; ?></a></td>
              <td valign="top"><?php echo ucfirst($type); ?></td>
              <td valign="top" align = "justify"><?php

		foreach ($ga as $g)
		{ 
		
		#echo "gc is $gc";
		//$gaa = "";
		$gaa=trim($g); 
		if($gc == 0)
		{
		$gg="<a href='gene_pcos.php?gene=$gaa' target='_blank'>$gaa<a/>";
		}
		else
		{
		$gg=$gg.", <a href='gene_pcos.php?gene=$gaa' target='_blank'>$gaa<a/>";
		}
		$gc++;
		
			}
		echo "<div align=justify>".$gg."</div>";   ?></td>
            </tr>
            <?php } ?>
            <?php		} ?>
            <?php $i++; }  ?>
          </table>
          <?php 
		    
	} ?>
        <?php } 
		elseif($opt==4)
	{
		?><h3 align="center"><?php echo "Search term: $qury"; ?></h3>
        <p align="left"><strong>SNP</strong></p>
        <table width="99%" border="0" cellspacing="0" cellpadding="2" bordercolor="#000000">
         <tr bgcolor="#DEEDEF">
         <td width="7%"><span class="style2">Gene</span></td>
        <td width="7%"><span class="style2">SNP Id</span></td>
        <td width="16%"><span class="style2">Upstream Sequence</span></td>
        <td width="25%" class="style2"><div align="center">SNP</div></td>
        <td width="25%"><span class="style2">Downstream Sequence</span></td>
        <td width="21%"><span class="style2">References</span></td>
                <td width="6%">&nbsp;</td>
                  </tr>
        <?php $ii=1;
		 while($row1 = mysql_fetch_array($res))
		{ ?>
      <tr <?php if($ii%2 == 0){ ?>bgcolor="#DEEDEF" <?php }?>>
      <td><?php $gene=$row1["gene_name"];
	  $gene1=str_replace($lookFor, $replacement, $gene);
	  echo $gene1; ?></td>
      <td><p>
        <?php 
			$snp_id=$row1["snp_id"];
			
	  $snp_id=str_replace($lookFor, $replacement, $snp_id);
	
			$sn_trm=substr($snp_id, 2);
			echo "<a href='http://www.ncbi.nlm.nih.gov/projects/SNP/snp_ref.cgi?rs=$sn_trm' target='_blank'>$snp_id</a>"; ?>
      </p></td>
      
        <td><?php 
        $upstream=$row1["upstream"];
			
	  $upstream=str_replace($lookFor, $replacement, $upstream); 
	  echo $upstream;
	  ?>        </td>
        <td><div align="center"><?php echo $row1["SNP"]; ?></div></td>
        <td><?php echo $row1["downstream"]; ?></td>
        <td><?php $snp_pmid = $row1["pmid"]; 
		//$snp_pmid = str_replace (" ", "", $snp_pmid);
			 
			$snp_pmid1=explode(",", $snp_pmid);
			$xi=0;
			$snp_pp="";
			foreach($snp_pmid1 as $snp_pmid11)
			{$snp_pmid11=trim($snp_pmid11);
			settype($snp_pmid11, "integer");
			if($snp_pmid11 >0)
			{
			if($xi == 0)
			{
			$snp_pp = "<a href='http://www.ncbi.nlm.nih.gov/pubmed?term=$snp_pmid11'  target='_blank'>".$snp_pmid11."</a>";
			
			}
			else
			{
			$snp_pp=$snp_pp.", <a href='http://www.ncbi.nlm.nih.gov/pubmed?term=$snp_pmid11' target='_blank'>".$snp_pmid11."</a>";
			}$xi++;
			}
			}
			echo $snp_pp;
			if($row1["c_sig"] == "")
			{}
			else
			{
			echo "<a href=".$row1["c_sig"]." target=_blank ><img src ='img/12829.gif'></a>";
			}
			?>          </td>
        <td width="6%"><a href="gene_pcos.php?gene=<?php echo $row1["gene_name"]; ?>"target="_blank">Gene...</a></td>
        </tr> <?php 
		$ii++;
		} 
		
		?>
    </table>
    <?php } 
		elseif($opt==5)
	{ if ($cnt1 > 0 )
	{
		?>
     <h3 align="center"><?php echo "Search term: $qury"; ?></h3>
     <p align="left"><strong>Associated Diseases</strong></p>
    
    
    <table width="100%" border="0" cellspacing="1" cellpadding="6" bordercolor="#000000">
  <tr align="center" valign="top" bgcolor="#DEEDEF">
    <td width="26%" align="left"><strong>Disease</strong></td>
    <td width="74%" align="left"><strong>Gene (Gene Symbol)</strong></td>
  </tr></table>
  <?php $i=1;
  while($row1=mysql_fetch_array($res))
	{ $disease=$row1["disease_merge"];
	$disease1=ucfirst($disease);
	$ress=mysql_query("select DISTINCT geneSymbol from disease_tertiary where disease_merge='$disease' order by geneSymbol");
	$num1=mysql_num_rows($ress);
	?>
    <div class="expander">
    
    <table width="100%" border="0" cellspacing="1" cellpadding="6" bordercolor="#000000">
  <tr <?php if($i%2 == 0){ ?>bgcolor="#DEEDEF" <?php }?>>
    <td  valign="top" width="26%"><a href="disease.php?qry=<?php echo $disease1; ?>"> <?php 
	$disease1=str_replace($lookFor, $replacement, $disease1);
	echo $disease1; ?></a></td>
   
    <?php 
	 $xa=0;
		if($num1>0)
		{
	?>
    <td width="74%" valign="top" align="justify">
    <?php while($row2=mysql_fetch_array($ress))
	{ $gensymb=trim($row2["geneSymbol"]);
	if($xa==0)
	{
		$dsg = "<a href='gene_pcos.php?gene=$gensymb' target= '_blank'>$gensymb</a>";
	}
	else
	  {
	  $dsg = "$dsg, <a href='gene_pcos.php?gene=$gensymb' target= '_blank'>$gensymb</a>";
	  }
		$xa++; } ?>
     <?php }
	 echo $dsg;
	  ?>      </td></tr></table></div>
      
  
  <?php $i++; } ?>

    
    
    <?php } }
		elseif($opt==8)
	{
		$i=1;
		
		?>
        <p align="center"><strong>References</strong></p>
        <?php
		while($rw2=mysql_fetch_array($res))
	{?>
    <table width="100%" border="0" align="right" cellpadding="5" cellspacing="=0">
           <tr>
            <td>
            
              <h4 onClick="toggle('<?php echo "pri".$i; ?>');"><a href="#ref"><?php echo $rw2["Title"];?></a>            </h4>
          <table width="100%" border="0" cellpadding="2" cellspacing="=0" align="left" >
           <tr>
            <td colspan="2"><div align="justify"><?php $auth = str_replace(',', '' ,$rw2["Full_Author"]);
			$auth = str_replace('|', ',' ,$auth);
			echo $auth;?></div></td>
          </tr>
          <tr>
            <td colspan="2"><div align="justify" ><?php echo $rw2["Affiliation"];?></div></td>
          </tr>
          <tr>
            <td colspan="2"><div align="justify"><?php echo $rw2["Source"];?></div></td>
          </tr>
           <tr>
            <td width="54%"><div align="justify"><strong>PMID: </strong><a href="http://www.ncbi.nlm.nih.gov/pubmed/<?php echo $rw2["PubMed_Unique_Identifier"];?>" target="_blank" ><?php echo $rw2["PubMed_Unique_Identifier"]; $ppmidd=$rw2["PubMed_Unique_Identifier"];
			?></a></div></td>
          
           <?php $res21 = mysql_query("select gene_name from gene where primary_references LIKE '%$ppmidd%' or references_all LIKE '%$ppmidd%'");  
		  $cnst=mysql_num_rows($res21);
		  ?>
          <td width="46%" >
          <?php if($cnst > 0)
		  {
			  ?>
		      <div align="right"><strong>Gene: 
		        <?php $xi=0;
		  while($rroe=mysql_fetch_array($res21)) 
		  {
			  $ggne=$rroe["gene_name"];
			  if($xi == 0)
			{
			$sr_mid = "<a href='gene_pcos.php?gene=$ggne' target='_blank'>".$ggne."</a>";
			
			}
			else
			{
			$sr_mid=$sr_mid.", <a href='gene_pcos.php?gene=$ggne' target='_blank'>".$ggne."</a>";
			}$xi++;
			}
			echo $sr_mid;
			  
		  ?>
		        </strong></div> <?php } ?></td></tr>
          <tr <?php echo "pri".$i; ?>=fred id="hidethis" style="display:none">
            <td colspan="2"><div align="justify">
              <p><div class="style26"><strong>Abstract</strong></div>
              <?php $abstract=$rw2["Abstract"];
			  $lookFor="PURPOSE:";
			  $replacement="<br><strong>PURPOSE:</strong>";
			  $abstract=str_replace($lookFor, $replacement, $abstract);
			  $lookFor="OBJECTIVES:";
			  $replacement="<br><strong>OBJECTIVES:</strong>";
			  $abstract=str_replace($lookFor, $replacement, $abstract);
			  $lookFor="OBJECTIVE:";
			  $replacement="<br><strong>OBJECTIVE:</strong>";
			  $abstract=str_replace($lookFor, $replacement, $abstract);
			  $lookFor="BACKGROUND:";
			  $replacement="<br><strong>BACKGROUND:</strong>";
			  $abstract=str_replace($lookFor, $replacement, $abstract);
			  $lookFor="METHODS:";
			  $replacement="<br><strong>METHODS:</strong>";
			  $abstract=str_replace($lookFor, $replacement, $abstract);
			  $lookFor="RESULTS:";
			  $replacement="<br><strong>RESULTS:</strong>";
			  $abstract=str_replace($lookFor, $replacement, $abstract);
			  $lookFor="CONCLUSIONS:";
			  $replacement="<br><strong>CONCLUSIONS:</strong>";
			  $abstract=str_replace($lookFor, $replacement, $abstract);
			  echo $abstract;?></div></td>
          </tr>
        </table></td>
          </tr></table>       
        <?php $i++; }?>
    
        <?php } 
		
		
		elseif($opt==6)
	{ 
	if ($cnt1 > 0 )
	{
		?>
     <h3 align="center"><?php echo "Search term: $qury"; ?></h3>
     <p align="left"><strong>Associated Pathways</strong></p>
    
    
    <table width="100%" border="0" cellspacing="1" cellpadding="6" bordercolor="#000000">
  <tr align="center" valign="top" bgcolor="#DEEDEF">
		<td width="25%" align="left"><strong>Pathway</strong></td>
		<td width="25%" align = "left"><strong>Pathway ID</strong></td>   
		<td width="40%" align="left"><strong>Gene (Gene Symbol)</strong></td>
      <td width="10%" align = "left"><strong>Source</strong></td>
    
  </tr>
  <?php 
  $i=1;

  while($row=mysql_fetch_array($res))
  {
			$pathn=$row['pathwayname'];
			$path=$row['pathwayid'];
			//echo "$path"."<br>";
			$path=trim($path);
			if (strpos($path, "R-HSA-") === FALSE){
			$ress=mysql_query("select geneSymbol, pathwayname, pathwayid, entrezid from kegg_path,gene where pathwayid = '$path' and kegg_path.entrezid = gene.entrez_gene");
			//echo "select geneSymbol, pathwayname, pathwayid, entrezid from kegg_path where pathwayid = '$path';";
			$link = '<a href="http://www.genome.jp/kegg-bin/show_pathway?'.$path.'" target="_blank">';
			$source = 'KEGG';
			}
			else{
			$ress=mysql_query("select geneSymbol, pathwayname, pathwayid, entrezid from reactome,gene where pathwayid = '$path' and reactome.entrezid = gene.entrez_gene");
			//echo "select geneSymbol, pathwayname, pathwayid, entrezid from kegg_path where pathwayid = '$path';";
			$link = '<a href="https://reactome.org/content/detail/ID/'.$path.'" target="_blank">';
			$source = 'Reactome';
			}
		?>
		
	    <tr <?php if($i%2 == 0){ ?> bgcolor="#DEEDEF" <?php }?> >
      <td><?php echo $link; echo $pathn; ?></a></td> 
	 
      <td> 
  <?php echo $path;  ?>
	  </td>
      <td align="justify">
	  <?php
	  $xa=0;
		while($row1=mysql_fetch_array($ress)){
	  if($xa==0)
	{
	?>
    <a href="gene_pcos.php?gene=<?php echo trim($row1["geneSymbol"]); ?>" target="_blank"><?php echo trim($row1["geneSymbol"]); ?></a>
      <?php
	}
	else
	  {
	  ?>
  , <a href="gene_pcos.php?gene=<?php echo trim($row1["geneSymbol"]); ?>" target ="_blank"><?php echo trim($row1["geneSymbol"]); ?> </a><?php 
	  }
	  $xa++;
		}
	  ?>
	  
	  </td>
		<td><?php echo $source; ?></td>
   		
		<?php 
  $i++;}
		?>
		 </tr>
		 </table>
		 <?php
	}}
		
		
	elseif($opt==7)
	{ if ($cnt1 > 0 )
	{
		?>
     <h3 align="center"><?php echo "Search term: $qury"; ?></h3>
     <p align="left"><strong>Associated miRNAs</strong></p>
    
    
    <table width="100%" border="0" cellspacing="1" cellpadding="6" bordercolor="#000000">
  <tr align="center" valign="top" bgcolor="#DEEDEF">
		<td width="15%" align="left"><strong>Gene (Gene Symbol)</strong></td>
		<td width="15%" align="left"><strong>Entrez ID</strong></td>
		<td width="30%" align="left"><strong>Gene Synonyms</strong></td>
		<td width="30%" align = "left"><strong>Function</strong></td>   
      <td width="10%" align = "left"><strong>Details</strong></td>
    
  </tr>
         <?php 
		$ii=1;
		while($row = mysql_fetch_array($res))
		{ ?>
      <tr <?php if($ii%2 == 0){ ?>bgcolor="#DEEDEF" <?php }?>>
        <td><div align="left"><a href="gene_pcos.php?gene=<?php echo $row["gene_name"]; ?>" target = "_blank" ><?php $gene_name=$row["gene_name"];
		 
			  $gene_name1=str_replace($lookFor, $replacement, $gene_name);
		echo $gene_name1; ?></a></div></td>
        <td><div align="left">
          <?php $gene_id=$row["entrez_gene"];
		
			  $gene_id=str_replace($lookFor, $replacement, $gene_id);
		echo $gene_id; ?>
        </div></td>
        <td><div align="left">
        
          <?php
		  $aliases=$row["aliases"];
		 
			  $aliases=str_replace($lookFor, $replacement, $aliases);
			   
		
		echo $aliases; ?>
        </div></td>
        <td valign="top"><div align="justify">
          <?php 
		$definition = $row["entrez_summary"]; $definition =trim($definition);
					$definition=ucfirst($definition);	
					$rep = array(" |", "  |", "|");
		$definition=str_replace($rep, ",", $definition);
		//$replacement = ",";
		//$lookFor=$rep;
		$definition=str_replace($lookFor, $replacement, $definition);
		echo $definition; ?>
        </div></td>
	   
        <td align="right" valign="bottom"><a href="gene_pcos.php?gene=<?php echo $row["gene_name"]; ?>" target = "_blank" >Details...</a></td>
        </tr> <?php  $ii++;} ?>
    </table>
    <?php }
 
		}
		?>       
		</td>
    </tr>
</table>
          
          <p>
            <?php } ?>
          </p>
          

  <div align="center">
 
  <form action="search1.php" method="post">
  <input name="qury" type="hidden" value="<?php echo $qury; ?>" />
  <input name="a" type="submit" value="Back" />
  </form>
          </div></td>
      </tr>
    </table>
        <p>&nbsp;</p></td>
      </tr>
    </table>
    </td>
  </tr>
 <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="5" align="center">
      <tr>
        
        
        <td width="21%" bgcolor="#46439a"><div align="center" class="style1"><strong><a href="stats.php"><font color="#ffffff">Statistics </font></a></strong></div></td>                                                                                           <td width="29%" bgcolor="#46439a"><div align="center" class="style1"><strong><a href="aboutus.php"><font color="#ffffff">About BIC</font></a></strong></div></td>
        <td width="25%" bgcolor="#46439a"><div align="center" class="style1"><strong><a href="feedback.php"><font color="#ffffff">Feedback</font></a></strong></div></td>
        
        <td width="25%" bgcolor="#46439a"><div align="center" class="style1"><strong><a href='contact.php'><font color="#ffffff">Contact Us</font></a></strong></div></td>
        
      </tr>
    </table></td>
</tr>
    </table>
    </td>
  </tr>
 <tr>
    <td></td>
  </tr>
</table>
<blockquote>
<p align="center" class="style13">
     | © 2020,  Biomedical Informatics Centre, NIRRH |<br/>
    ICMR-National Institute for Research in Reproductive Health, Jehangir Merwanji Street, Parel, Mumbai-400   012<br>
    Tel: 91-22-24192104, Fax No: 91-22-24139412</p>
    </blockquote>
    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>
