var version = '1.22.0';
export default version;
