// JavaScript Document
$(document).ready(function() {
       $("#myH").click(function() {
		   document.myForm.action = "dataDownload.php";
           $("#myForm").submit();
       });
	   $("#myH1").click(function() {
		   document.myForm.action = "http://www.camp.bicnirrh.res.in/ncbiBlast/index.php";
           $("#myForm").submit();
       });
	   $("#myH2").click(function() {
		   document.myForm.action = "http://www.camp.bicnirrh.res.in/clustalW/index.php";
           $("#myForm").submit();
       });
    });